﻿using System;
using System.Drawing;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace np_image_manual_client
{
    public partial class Form1 : Form
    {
        // Our normal setup.
        TcpClient client;
        NetworkStream ns;

        // To deal with the path of the selected image.
        private string selectedImagePath;

        public Form1()
        {
            InitializeComponent();
        }

        private async void ConnectButton_Click(object sender, EventArgs e)
        {
         
                client = new TcpClient();
                await client.ConnectAsync("127.0.0.1", 5000);

                ns = client.GetStream();

                // To make our client always be able to receive an image.
                while (true)
                {
                        // Array to receive the size of the incoming image.
                        byte[] sizeData = new byte[4];

                        // Read the size asynchronously.
                        await ns.ReadAsync(sizeData, 0, sizeData.Length);

                        // Convert the size to integer form.
                        int imageSize = BitConverter.ToInt32(sizeData, 0);

                        // Array to receive the image data.
                        byte[] imageData = new byte[imageSize];

                        // Variable to track the bytes read from the network stream.
                        int totalBytesRead = 0;

                        // Loop until all image data are read.
                        while (totalBytesRead < imageSize)
                        {
                            // Read image data asynchronously.
                            int bytesRead = await ns.ReadAsync(imageData, totalBytesRead, imageSize - totalBytesRead);

                            // Increment the total bytes read.
                            totalBytesRead += bytesRead;
                        }

                        // Display the image in the PictureBox
                        using (MemoryStream memoryStream = new MemoryStream(imageData))
                        {
                            ImageShowBox.Image = Image.FromStream(memoryStream);
                        }

                        // MessageBox.Show("Image received and displayed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                  
                }
            
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            // Create instance of the OpenFileDialog class.
            OpenFileDialog openFileDialog = new OpenFileDialog();

            // Set the file filter to limit file selection to image files only
            openFileDialog.Filter = "Image Files (*.jpg;*.jpeg;*.png;*.gif)|*.jpg;*.jpeg;*.png;*.gif|All files (*.*)|*.*";

            // Display the OpenFileDialog object and wait for the user to make a selection.
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // If the user selects a file and clicks OK,
                // store the selected file path in the selectedImagePath variable.
                selectedImagePath = openFileDialog.FileName;

                // Set the PictureBox control's SizeMode property
                // to stretch the image to fit the PictureBox dimensions.
                ImageShowBox.SizeMode = PictureBoxSizeMode.StretchImage;

                // Show the selected image into the PictureBox.
                ImageShowBox.Image = new Bitmap(openFileDialog.FileName, false);
            }
        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            // Check if the path is null or empty.
            if (string.IsNullOrEmpty(selectedImagePath))
            {
                MessageBox.Show("Please select an image first.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

          
                // Read all bytes from the path to a byte array.
                byte[] imageData = File.ReadAllBytes(selectedImagePath);

                // Convert the length of the image data to a byte array.
                // We do this to be able to send it on our network stream.
                byte[] sizeData = BitConverter.GetBytes(imageData.Length);

                // Send the size of the image.
                ns.Write(sizeData, 0, sizeData.Length);
                ns.Flush();

                // Send the image data.
                ns.Write(imageData, 0, imageData.Length);
                ns.Flush();

                // Just for debugging.
                // MessageBox.Show("Image sent successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
           
        }
    }
}
